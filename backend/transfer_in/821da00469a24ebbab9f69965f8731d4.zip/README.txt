Tres Ninos STARTER file: the shop's real inventory (Hardware_Inventory.docx, cash price = selling price,
cost = 65% of it) and the 7 sales persons with their phone logins.
Open it in the shop program: Transfer -> Read a setup file -> Apply.
It holds the phone passwords only as one-way codes (PBKDF2), never the passwords themselves. Keep it private;
you can delete it after applying.
