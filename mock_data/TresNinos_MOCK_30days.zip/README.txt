Tres Niños setup file. On the other laptop: Transfer -> Read a setup file -> tick what to apply.
Has the sales too (no receipt photos). Has no receipt photos, accounts or passwords.
