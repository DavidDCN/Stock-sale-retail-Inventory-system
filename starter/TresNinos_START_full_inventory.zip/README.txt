Tres Ninos START file: the 7 sales persons with their phone logins + the WHOLE inventory
(old list + new_inventory.docx + Inventory_Part_2.docx, 618 types). Transfer -> Read a setup file -> tick Employees
and Supply -> Apply. PRIVATE: holds the phone logins (as one-way codes); do not share it.
