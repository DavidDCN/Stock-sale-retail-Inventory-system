Tres Ninos setup file: the NEW inventory from new_inventory.docx (Supply only, 259 types).
TresNinosShop -> Transfer -> Read a setup file -> choose this ZIP -> tick Supply -> Apply.
Nothing is deleted; items already in Supply with the same name are not touched unless you tick
'Update the ones that already exist here'.
